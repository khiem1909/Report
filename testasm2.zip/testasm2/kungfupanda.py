import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress
import numpy as np

# Load the data from the Excel file
data = pd.read_excel("saledatabase.xlsx",sheet_name="Sheet1")  # Adjust sheet name if necessary

# For this example, let's assume that the 'saledatabase.xlsx' file has two columns: 'Sales' and 'Advertising Cost'
# You need to replace these column names with the actual column names in your Excel file

# Extract the relevant columns for the linear regression
x = data['ProductID']  # Independent variable (x-axis)
y = data['TrendingScore']  # Dependent variable (y-axis)

# Calculate the linear regression
result = linregress(x, y)

# Print the slope and intercept of the regression line
print(f"Slope: {result.slope}")
print(f"Intercept: {result.intercept}")

# Create a scatter plot of the data
plt.scatter(x, y, color='blue')

# Create a line plot of the regression line
x_line = np.linspace(x.min(), x.max(), 100)
y_line = result.slope * x_line + result.intercept
plt.plot(x_line, y_line, color='red')

# Display the plot
plt.title('Linear Regression of Sales vs Advertising Cost')
plt.xlabel('Advertising Cost')
plt.ylabel('Sales')
plt.show()
